﻿/* 2 - Escreva uma função que receba um parâmetro do tipo string e retorne uma string como
resultado. A função deverá "compactar" a string recebida como parâmetro de entrada. A
compactação funcionará escrevendo o caractere encontrado seguido da quantidade de vezes que
ele ocorre em sequência.
Ex.:
Parâmetro de entrada: jjjjooaoo
Resultado da função: j4o2ao2*/

namespace projetotasken1
{
    public class Segundaquestao
    {
        static void Main(string[] args)
        {
            Console.WriteLine(contaLetra("jjjjooaoo"));
        }

        public static string contaLetra(string palavra)
        {


            string novaPalavra = "";
            string letra = "";
            int conta = 0;

            for (int i = 0; i < palavra.Length; i++)
            {



                if (letra == palavra.Substring(i, 1))
                {
                    conta++;
                }
                else
                {
                    if (conta == 0) novaPalavra = novaPalavra + letra;
                    if (conta > 0)
                    {
                        conta++;
                        novaPalavra = novaPalavra + letra + conta;
                    }
                    conta = 0;
                }
                letra = palavra.Substring(i, 1);
            }

            if (conta == 0) novaPalavra = novaPalavra + letra;
            if (conta > 0)
            {
                conta++;
                novaPalavra = novaPalavra + letra + conta;
            }
            return novaPalavra;
        }
    }
}