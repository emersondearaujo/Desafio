﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.Intrinsics.X86;
using System.Text;
using System.Threading.Tasks;

/*3-Escreva um programa que leia números positivos do teclado, até que o número zero seja
digitado. Após, o programa deverá exibir um relatório na tela descrevendo os seguintes itens:
a) Quantos números foram lidos.
b) O maior numero lido.
c) A média dos números lidos.
d) O menor número ímpar lido (caso algum número ímpar tenha sido digitado).
e) A quantidade de vezes que cada número ocorreu. Exemplo: "O número 7 ocorreu 2 vezes."
"O número 13 ocorreu 8 vezes".
DICA: Use vetores.*/

namespace projetotasken1
{
    internal class Terceiraquestao
    {
        static void Main()
        {
            List<int> numeros = new List<int>();
            int numero;
            int maior = int.MinValue;
            int menorImpar = int.MaxValue;
            int soma = 0;
            Dictionary<int, int> ocorrencias = new Dictionary<int, int>();

            while (true)
            {
                Console.Write("Digite um número (ou 0 para sair): ");
                if (int.TryParse(Console.ReadLine(), out numero))
                {
                    if (numero == 0)
                        break;

                    numeros.Add(numero);

                    // Verifica o maior número
                    if (numero > maior)
                        maior = numero;

                    // Verifica o menor número ímpar
                    if (numero % 2 != 0 && numero < menorImpar)
                        menorImpar = numero;

                    // Soma os números
                    soma += numero;

                    // Conta as ocorrências dos números
                    if (ocorrencias.ContainsKey(numero))
                    {
                        ocorrencias[numero]++;
                    }
                    else
                    {
                        ocorrencias[numero] = 1;
                    }
                }
                else
                {
                    Console.WriteLine("Número inválido. Tente novamente.");
                }
            }

            Console.WriteLine($"Quantidade de números lidos: {numeros.Count}");
            Console.WriteLine($"Maior número lido: {maior}");
            Console.WriteLine($"Média dos números lidos: {(double)soma / numeros.Count}");

            if (menorImpar != int.MaxValue)
                Console.WriteLine($"Menor número ímpar lido: {menorImpar}");
            else
                Console.WriteLine("Nenhum número ímpar lido.");

            foreach (var item in ocorrencias)
            {
                Console.WriteLine($"O número {item.Key} ocorreu {item.Value} vez{(item.Value > 1 ? "es" : "")}.");
            }
        }
    }
}
