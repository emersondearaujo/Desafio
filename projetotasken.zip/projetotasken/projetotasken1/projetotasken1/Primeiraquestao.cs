﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

/* 1- Escreva uma função que receba um valor inteiro como parametro de entrada e imprima na tela n linhas conforme estruturada apresentada abaixo. Por exemplo, as seguintes linhas devem ser apresentadas ser o parametro de entrada for 10.
Nota: Caso seja inserido um valor menor ou igual a zero, uma critica deverá ser exibida e o processo deverá ser abortado.*/

namespace projetotasken1
{
    public class Primeiraquestao
    {
        static void Main()
        {
            Console.WriteLine("Escreva um número");
            int NumeroASerInserido = int.Parse(Console.ReadLine());
            if (NumeroASerInserido > 0)
            {
                for (int i = NumeroASerInserido; i > 0; i--)
                {
                    for (int j = i; j > 0; j--)
                    {
                        int multi = j * j;
                        Console.Write(multi + " ");
                    }
                    Console.WriteLine();
                }
            }
            else
            {
                Console.WriteLine("Escreva um valor válido");
            }
        }
    }
}
