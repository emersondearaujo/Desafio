﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Text.RegularExpressions;
using System.Threading.Tasks;

/*4 - Escreva um programa que leia um arquivo texto (.txt) escolhido pelo usuário. Após a leitura
do arquivo, o programa deverá exibir qual linha possui mais vogais e qual linha possui mais
consoantes. Por simplicidade admita que o arquivo conterá apenas letras (sem acentos ou ç) e
espaços em branco. Caso ocorra empate, qualquer uma das linhas poderá ser exibida.*/

namespace projetotasken1
{
    internal class Quartaquestao
    {
        static void Main()
        {
            Console.Write("Digite o caminho completo do arquivo .txt: ");
            string caminhoArquivo = Console.ReadLine();

            if (File.Exists(caminhoArquivo))
            {
                string[] linhas = File.ReadAllLines(caminhoArquivo);

                int linhaComMaisVogais = -1;
                int quantidadeMaximaVogais = -1;

                int linhaComMaisConsoantes = -1;
                int quantidadeMaximaConsoantes = -1;

                for (int i = 0; i < linhas.Length; i++)
                {
                    string linha = linhas[i];
                    int quantidadeVogais = ContarVogais(linha);
                    int quantidadeConsoantes = ContarConsoantes(linha);

                    if (quantidadeVogais > quantidadeMaximaVogais)
                    {
                        quantidadeMaximaVogais = quantidadeVogais;
                        linhaComMaisVogais = i;
                    }

                    if (quantidadeConsoantes > quantidadeMaximaConsoantes)
                    {
                        quantidadeMaximaConsoantes = quantidadeConsoantes;
                        linhaComMaisConsoantes = i;
                    }
                }

                Console.WriteLine($"A linha com mais vogais é a linha {linhaComMaisVogais + 1}");
                Console.WriteLine($"A linha com mais consoantes é a linha {linhaComMaisConsoantes + 1}");
            }
            else
            {
                Console.WriteLine("Arquivo não encontrado.");
            }
        }

        static int ContarVogais(string texto)
        {
            return Regex.Matches(texto, "[]").Count;
        }

        static int ContarConsoantes(string texto)
        {
            return Regex.Matches(texto, "[]").Count;
        }
    }
}
