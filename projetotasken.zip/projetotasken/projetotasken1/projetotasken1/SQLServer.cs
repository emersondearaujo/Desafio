﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Reflection.Emit;
using System.Runtime.Intrinsics.X86;
using System.Text;
using System.Text.RegularExpressions;
using System.Threading.Tasks;

namespace projetotasken1
{
    internal class SQLServer
    {
        /* 5 - Escreva o script necessário para a criação de uma tabela chamada CLIENTES e outra
chamada TELEFONES.A tabela CLIENTES deverá possuir os seguintes campos: NOME, CPF
e IDADE sendo o CPF a chave primária.
A tabela TELEFONES deverá possuir três campos, sendo eles: CPF_CLIENTE, DDD e
TELEFONE, para esta tabela o campo CPF_CLIENTE deverá ser a chave primária e estrangeira
(referenciando o campo CPF da tabela CLIENTES)*/

     //Criação da tabela CLIENTES
    CREATE TABLE CLIENTES(
    CPF VARCHAR(11) PRIMARY KEY,
    NOME VARCHAR(255),
    IDADE INT
);
//Criação da tabela TELEFONES
    CREATE TABLE TELEFONES(
    CPF_CLIENTE VARCHAR(11) PRIMARY KEY,
    DDD VARCHAR(2),
    TELEFONE VARCHAR(9),
    FOREIGN KEY(CPF_CLIENTE) REFERENCES CLIENTES(CPF)
);

           /*Utilize as tabelas criadas anteriormente para responder as questões 6,7 e 8.
6 - Escreva uma consulta SQL para obter o nome de todos os clientes que possuam idade igual
ou superior a 22 anos.O resultado deverá estar ordenado pela idade de forma crescente.*/

     SELECT NOME
     FROM CLIENTES
     WHERE IDADE >= 22
     ORDER BY IDADE ASC;

        /*7 - Escreva uma consulta SQL que exiba o nome dos clientes e a quantidade de telefones
encontrados.A consulta deverá exibir somente o nome dos clientes que possuam pelo menos 1
telefone*/

     SELECT C.NOME, COUNT(T.CPF_CLIENTE) AS QUANTIDADE_TELEFONES
     FROM CLIENTES C
     LEFT JOIN TELEFONES T ON C.CPF = T.CPF_CLIENTE
     GROUP BY C.NOME
     HAVING COUNT(T.CPF_CLIENTE) >= 1;

        /*8 – Escreva o comando SQL necessário para excluir todos os clientes que possuam o sobrenome
‘santos’.*/

     DELETE FROM CLIENTES
     WHERE NOME LIKE '% Santos';

    }
}
